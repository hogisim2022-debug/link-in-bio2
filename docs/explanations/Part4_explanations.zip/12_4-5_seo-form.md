# SEO Settings 폼

**완료한 task:** `4. Admin 페이지 > 4-5. SEO Settings`  
**수정 파일:** `components/admin/AdminClient.tsx`, `app/globals.css`

---

## 무엇을 했나?

설정 패널에 SEO 설정 섹션이 추가됐다.  
페이지 제목과 Meta Description을 입력할 수 있고, 권장 글자 수를 실시간으로 표시한다.

```
┌────────────────────────────────────────────┐
│  페이지 제목                               │
│  ┌──────────────────────────────────────┐  │
│  │  AI전공 AI교육 강사 | 김강사         │  │
│  └──────────────────────────────────────┘  │
│  20 / 60자 권장                            │  ← 실시간 글자 수
│                                            │
│  설명 (Meta Description)                   │
│  ┌──────────────────────────────────────┐  │
│  │  강의경력 8년, 삼성 출강 경험.       │  │
│  │  기업·공공기관 AI 교육 전문 강사...  │  │
│  │                                      │  │
│  └──────────────────────────────────────┘  │
│  45 / 160자 권장                           │  ← 실시간 글자 수
│                                            │
│  ┌──────────────────────────────────────┐  │
│  │  OG 이미지 업로드는 Supabase 연동 후 │  │  ← 안내 박스
│  └──────────────────────────────────────┘  │
└────────────────────────────────────────────┘
```

---

## 핵심 개념 1: SEO 메타태그란?

```html
<title>AI전공 AI교육 강사 | 김강사</title>
<meta name="description" content="강의경력 8년..." />
<meta property="og:title" content="..." />
```

검색 엔진(구글)이 페이지를 색인할 때 읽는 정보다.  
- **title**: 구글 검색 결과에서 파란 링크 텍스트
- **description**: 제목 아래 회색 요약 설명
- **og:image**: 카카오톡/슬랙 등에 링크를 공유할 때 나오는 썸네일

권장 글자 수를 지키지 않으면 검색 결과에서 잘려서 표시된다.  
(title: 60자, description: 160자)

---

## 핵심 개념 2: 글자 수 힌트

```tsx
const [seo, setSeo] = useState({ title: "", description: "" });

<p className="admin-field__hint">{seo.title.length} / 60자 권장</p>
```

`String.length`는 글자 수를 반환한다.  
`seo.title`이 바뀔 때마다 React가 `<p>`를 다시 렌더링하므로 실시간으로 숫자가 갱신된다.  
별도 계산 없이 상태에서 직접 읽는다.

---

## 핵심 개념 3: `<textarea>` vs `<input>`

```tsx
<textarea
  className="admin-field__input admin-field__textarea"
  rows={3}
  value={seo.description}
  onChange={(e) => setSeo({ ...seo, description: e.target.value })}
/>
```

Meta Description은 여러 줄이 될 수 있으므로 `<textarea>`를 사용한다.  
`<input>`과 똑같이 `value` + `onChange`로 제어한다.  
`rows={3}`은 초기 높이, `resize: vertical` CSS로 수동 조절도 가능하다.

---

## 다음 단계

- Supabase 연동 후 저장 버튼 → `profile` 테이블 `seo_title`, `seo_description` UPDATE
- OG 이미지 업로드 → Supabase Storage 연동 후 구현
- `app/page.tsx`의 `metadata`를 `generateMetadata`로 변경해 DB 데이터 동적 반영
