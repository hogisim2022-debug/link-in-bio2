# Lucide React 아이콘

**완료한 task:** `5. 디자인 시스템 > 아이콘: Lucide React`  
**수정 파일:** `components/public/LinkItem.tsx`, `components/public/FloatingCTA.tsx`, `components/admin/AdminShell.tsx`

---

## 왜 Lucide인가?

`index.html`에서는 이모지(💬, ✉️, 📄)를 아이콘으로 사용했다.  
이모지는 OS마다 모양이 달라서 디자인 일관성을 보장할 수 없다.  
Lucide는 2px stroke, rounded cap의 SVG 아이콘 세트로, 디자인 시스템 README에 명시된 아이콘 소스다.

---

## 핵심 개념: SVG 아이콘 컴포넌트

- SVG는 Scalable Vector Graphics의 줄임말
- 쉽게 말하면 확대해도 깨지지 않는 이미지 형식

🧩 핵심 개념
- 픽셀로 이루어진 이미지(예: JPG, PNG)가 아니라
- 수학적인 좌표와 선, 도형으로 그린 이미지

그래서 아무리 확대해도 선이 또렷함 👍


## 적용된 곳

| 위치 | 아이콘 | 용도 |
|------|--------|------|
| `LinkItem` | `MessageCircle`, `Mail`, `FileText`, `PenLine`, `Link2` | 링크 타입별 아이콘 |
| `LinkItem` | `ChevronRight` | 화살표 (`›` 대체) |
| `FloatingCTA` | `MessageCircle` | 문의 버튼 |
| `AdminShell` | `LogOut` | 로그아웃 버튼 |

---

## 다음 단계

- Admin 설정 패널 폼 완성 시 `Save`, `Trash2`, `GripVertical`(드래그) 등 추가
