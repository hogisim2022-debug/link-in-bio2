# 기본 폴더 구조

**완료한 task:** `0. 프로젝트 셋업 > 기본 폴더 구조 생성`  
**생성 파일:** `components/public/*`, `components/admin/*`, `lib/types.ts`, `lib/supabase/client.ts`, `lib/supabase/server.ts`

---

## 만들어진 구조

```
├── app/
│   ├── layout.tsx
│   ├── globals.css
│   └── page.tsx
│
├── components/
│   ├── public/          ← 방문자가 보는 페이지 컴포넌트
│   │   ├── Hero.tsx
│   │   ├── TrustBar.tsx
│   │   ├── LinkItem.tsx     (LinkItem / CardItem / OverflowCardItem)
│   │   ├── FloatingCTA.tsx
│   │   └── Footer.tsx
│   │
│   └── admin/           ← 관리자 페이지 컴포넌트
│       ├── DashboardStats.tsx
│       ├── LinkEditor.tsx
│       ├── PreviewPane.tsx
│       ├── ProfileForm.tsx
│       └── SEOForm.tsx
│
└── lib/
    ├── types.ts             ← DB 테이블 타입 정의
    └── supabase/
        ├── client.ts        ← 브라우저용 Supabase 클라이언트
        └── server.ts        ← 서버용 Supabase 클라이언트
```

---

## 핵심 개념 1: 컴포넌트를 왜 나누는가?

`index.html`에는 모든 HTML이 한 파일에 있다.  
Next.js에서는 UI를 **컴포넌트**라는 독립된 조각으로 나눈다.

```
index.html (1개 파일, 600줄)
       ↓ 분리
Hero.tsx (프로필 영역)
TrustBar.tsx (경력 + 로고 슬라이더)
LinkItem.tsx (링크 목록)
FloatingCTA.tsx (하단 고정 버튼)
```

장점:
- **재사용**: `PreviewPane`(관리자 미리보기)에서 Public 컴포넌트를 그대로 가져다 쓴다.
- **유지보수**: FloatingCTA 버튼 색을 바꾸려면 `FloatingCTA.tsx` 하나만 열면 된다.
- **협업**: 팀 작업 시 담당 파일이 명확하게 나뉜다.

---

## 핵심 개념 2: `"use client"` 지시어

파일 맨 위에 `"use client"`가 있는 것과 없는 것이 있다.

| | Server Component (기본값) | Client Component (`"use client"`) |
|---|---|---|
| **실행 위치** | 서버에서 HTML 생성 | 브라우저에서 실행 |
| **데이터** | DB 직접 조회 가능 | `useState`, 이벤트 핸들러 사용 가능 |
| **예시** | Hero, TrustBar, Footer | LinkEditor, ProfileForm |

**규칙**: 클릭/입력 같은 사용자 인터랙션이 필요하면 `"use client"`, 데이터를 보여주기만 하면 Server Component로 둔다.

관리자 컴포넌트(`LinkEditor`, `ProfileForm` 등)는 폼 입력과 버튼 클릭이 있으므로 `"use client"`가 붙는다.

---

## 핵심 개념 3: Supabase 클라이언트가 두 개인 이유

```
lib/supabase/client.ts  ← 브라우저에서 실행
lib/supabase/server.ts  ← 서버에서 실행
```

Next.js App Router에서는 서버 컴포넌트와 클라이언트 컴포넌트가 다른 환경에서 실행된다.  
Supabase는 이 두 환경에 맞는 별도 클라이언트를 제공한다.

- **server.ts**: 공개 페이지(`/`)에서 Supabase DB 데이터를 읽을 때 사용. 쿠키로 인증 상태를 확인한다.
- **client.ts**: 관리자 페이지에서 버튼 클릭 → 데이터 저장 같은 인터랙션에 사용.

두 파일 모두 현재는 주석 처리 상태다. Supabase 프로젝트 생성 후 `.env.local`을 설정하면 활성화한다.

---

## 핵심 개념 4: TypeScript 타입 (`lib/types.ts`)

```ts
export interface Link {
  id: string;
  user_id: string;
  title: string;
  url: string;
  type: LinkType;          // "link" | "card" | "overflow_card" | "youtube"
  is_visible: boolean;
  click_count: number;
  // ...
}
```

PRD 9절의 DB 스키마를 TypeScript 타입으로 그대로 옮긴 것이다.  
이 타입을 컴포넌트의 props에 지정하면, 잘못된 데이터가 넘어올 때 빌드 단계에서 오류가 난다.  
런타임 오류를 사전에 잡는다.

---

## 다음 단계

- Supabase 프로젝트 생성 후 `.env.local` 설정
- `lib/supabase/client.ts`, `server.ts` 주석 해제
- `components/public/` 컴포넌트에 `index.html` UI 이식 시작
