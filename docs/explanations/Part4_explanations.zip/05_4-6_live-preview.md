# Live Preview (실시간 미리보기)

**완료한 task:** `4. Admin 페이지 > 4-6. Live Preview`  
**생성/수정 파일:** `components/admin/AdminClient.tsx`, `app/admin/page.tsx`, `app/globals.css`

---

## 무엇을 했나?

설정 패널의 입력값이 바뀌면 오른쪽 미리보기에 즉시 반영되도록 구현했다.  
이름, 한 줄 소개, 경력 필드를 수정하면 저장 없이 미리보기가 실시간으로 갱신된다.

<img src="image-1.png" width="400" />

---

## 핵심 개념 1: 상태 끌어올리기 (State Lifting)

설정 폼과 미리보기는 **같은 데이터**를 바라봐야 한다.  
두 컴포넌트가 데이터를 공유하려면 그 데이터를 **둘의 공통 부모**가 가지고 있어야 한다.

```
AdminClient (상태 보관)
├── 설정 패널 → profile 상태를 읽고 onChange로 수정
└── Live Preview → profile 상태를 읽어서 렌더링
```

```tsx
// AdminClient.tsx
const [profile, setProfile] = useState<Profile>(initialProfile);

// 설정 패널: 상태를 수정
<input value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />

// 미리보기: 같은 상태를 읽음
<Hero profile={profile} />
```

`profile.name`이 바뀌면 React가 자동으로 미리보기를 다시 그린다.

---

## 다음 단계

- Supabase 연동 후 저장 버튼 → DB `UPDATE` 호출
- 링크 목록도 상태로 관리해서 링크 추가/삭제 시 미리보기 즉시 반영
