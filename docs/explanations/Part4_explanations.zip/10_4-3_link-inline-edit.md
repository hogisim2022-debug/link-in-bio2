# 링크 수정 인라인 에디터

**완료한 task:** `4. Admin 페이지 > 4-3. Link Manager > 링크 수정 인라인 에디터`  
**수정 파일:** `components/admin/LinkEditor.tsx`, `app/globals.css`

---

## 무엇을 했나?

각 링크 행의 연필 아이콘을 클릭하면 바로 아래 편집 폼이 펼쳐진다.  
제목, URL, 타입을 수정하고 저장하면 목록과 Live Preview에 즉시 반영된다. 취소하면 원래 값으로 돌아온다.

<img src="image.png" width="300">


---



저장 버튼을 누르기 전까지는 `draft`만 바뀌고 실제 `link` 데이터는 그대로다.  
Supabase 연동 후에는 `saveEdit`에서 DB UPDATE를 호출하고, 실패 시 `cancelEdit`로 롤백한다.

---

## 핵심 개념 3: 인라인 폼 UI 구조

```
┌─────────────────────────────────┐  ← link-editor__row (기본 행)
│ ⠿  카카오톡 문의  ✏️  👁  🗑️   │
└─────────────────────────────────┘
┌─────────────────────────────────┐  ← link-editor__inline-form (편집 시 노출)
│  제목: [__________]             │
│  URL:  [__________]             │
│  타입: [기본형   ▼]             │
│  [✓ 저장]  [✕]                 │
└─────────────────────────────────┘
```

`border-top: none`으로 기본 행과 인라인 폼이 하나처럼 붙어 보이도록 했다.

---

## 다음 단계

- Supabase 연동 후 `saveEdit`의 TODO에서 `links` 테이블 UPDATE 호출
- 저장 실패 시 `cancelEdit`로 롤백
