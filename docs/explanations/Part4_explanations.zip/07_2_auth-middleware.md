# 인증 — 로그인 페이지 & Next.js Middleware

**완료한 task:** `2. 인증 > 로그인 페이지, 로그인 폼, Middleware 구조`  
**생성 파일:** `middleware.ts`, `app/login/page.tsx`

---

## 만들어진 구조

```
/login              ← 로그인 폼 (이메일 + 비밀번호)
middleware.ts       ← /admin 접근 시 세션 체크 → 없으면 /login으로 redirect
```

```
┌──────────────────────────────────┐
│            [ 🔒 ]                │
│         관리자 로그인             │
│         강사 전용 페이지          │
│                                  │
│  이메일                          │
│  ┌──────────────────────────┐    │
│  │  admin@example.com       │    │
│  └──────────────────────────┘    │
│                                  │
│  비밀번호                        │
│  ┌──────────────────────────┐    │
│  │  ••••••••                │    │
│  └──────────────────────────┘    │
│                                  │
│  ┌──────────────────────────┐    │
│  │         로그인           │    │  ← pill 버튼 (green)
│  └──────────────────────────┘    │
└──────────────────────────────────┘
```

---
## 세션(session)
사용자가 로그인 상태인지 서버가 기억하고 있는 정보

1. 로그인하면 서버 처리 순서
- 로그인 성공
- 서버가 세션 ID를 생성
- 그걸 브라우저 쿠키에 저장
- 이후 요청마다 쿠키가 같이 보내짐
- 서버는 “아 이 사람 로그인 했던 사용자구나” 판단

2. 로그아웃하면 서버가 쿠키를 삭제  
- 서버는 “이 사용자 더 이상 로그인 안 됐어”라고 판단  
- 다시 /login으로 보냄

## 브라우저 쿠키(cookie)
웹사이트가 사용자의 브라우저에 저장하는 작은 데이터 조각
> “이 정보 좀 네 컴퓨터에 잠깐 맡겨둘게. 다음에 다시 올 때 가져와.”

```
🔐 로그인 유지 (세션 ID 저장)
🌐 사용자 설정 기억 (언어, 다크모드 등)
🛒 장바구니 정보
📊 방문 기록 / 트래킹
```

### 동작 방식
```
1. 서버가 응답할 때 쿠키를 내려줌
2. 브라우저가 쿠키 저장
3. 이후 같은 사이트 요청할 때마다 자동으로 쿠키 같이 보냄
```

### 세션이랑 관계
- 쿠키 안에는 보통 세션 ID가 들어 있음
- 서버는 그 ID로 로그인 상태를 판단함

### 특징
- 용량 작음 (보통 몇 KB)
- 만료 시간 설정 가능 (자동 로그아웃)

## 핵심 개념 1: Next.js Middleware

Middleware는 요청이 페이지에 도달하기 **전에** 실행되는 코드다.  
브라우저가 `/admin`을 열려고 하면, 페이지를 렌더링하기 전에 middleware가 먼저 실행된다.

```ts
// middleware.ts
export function middleware(request: NextRequest) {
  if (pathname.startsWith("/admin")) {
    // 세션 확인 → 없으면 /login으로 redirect
  }
}

export const config = {
  matcher: ["/admin/:path*"],  // 이 경로에만 middleware 적용
};
```

## 핵심 개념 2: 현재 상태 (개발용 bypass)

```ts
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
if (!supabaseUrl) return NextResponse.next();  // env 없으면 통과
```

Supabase가 연결되지 않은 지금은 환경변수가 없으므로 `/admin`에 자유롭게 접근할 수 있다.  
`.env.local`에 Supabase URL이 추가되는 순간 아래 TODO 코드를 해제하면 실제 인증이 작동한다.

```ts
// TODO: Supabase Auth 연동 후 해제
// const session = await getSession(request);
// if (!session) return NextResponse.redirect(new URL("/login", request.url));
```

---

## 핵심 개념 3: 로그인 폼 상태 관리

```tsx
const [email, setEmail] = useState("");
const [password, setPassword] = useState("");
const [error, setError] = useState("");
const [loading, setLoading] = useState(false);
```

로그인 폼은 4개의 상태를 가진다.
- `email`, `password`: 입력값
- `error`: 실패 메시지 (잘못된 비밀번호 등)
- `loading`: 제출 중 버튼 비활성화 + 텍스트 변경

`handleSubmit`은 현재 개발용 더미 로직이다.  
(`admin@example.com` / `password` 로 로그인하면 `/admin`으로 이동)  
Supabase 연동 후 `supabase.auth.signInWithPassword()`로 교체한다.

---


## 다음 단계

- Supabase Auth 연동 후 `middleware.ts` TODO 해제 → 실제 세션 기반 보호
- 로그아웃 버튼 → `supabase.auth.signOut()` 후 `/login` redirect
