# Link Manager (Drag & Drop)

**완료한 task:** `4. Admin 페이지 > 4-3. Link Manager`  
**수정 파일:** `components/admin/LinkEditor.tsx`, `components/admin/AdminClient.tsx`, `app/globals.css`

---

## 무엇을 했나?

Admin 설정 패널에 링크 목록이 나타나고, 드래그로 순서를 바꾸거나 눈 아이콘으로 노출을 토글하거나 삭제할 수 있다. 변경사항은 오른쪽 Live Preview에 즉시 반영된다.

```
┌──────────────────────────────────────────────┐
│ ⠿  카카오톡 문의           ✏  👁  🗑        │  ← 드래그 핸들 / 수정 / 노출 / 삭제
├──────────────────────────────────────────────┤
│ ⠿  이메일 문의             ✏  👁  🗑        │
├──────────────────────────────────────────────┤
│ ⠿  ~~강의 소개 페이지~~    ✏  🙈  🗑        │  ← 숨김 상태: 취소선 + 눈 감김
├──────────────────────────────────────────────┤
│ ⠿  AI 교육 블로그          ✏  👁  🗑        │
└──────────────────────────────────────────────┘
┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
          +  링크 추가
└ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┘
```

---

## 핵심 개념 1: @dnd-kit 구조

`@dnd-kit`은 세 레이어로 나뉜다.

```
DndContext          ← 드래그 이벤트 감지 (어디서 잡고, 어디에 놓았는지)
└── SortableContext ← 정렬 가능한 아이템 목록 관리
    └── useSortable ← 각 아이템에 드래그 능력 부여
```


## 핵심 개념 2: `arrayMove`로 순서 변경

드래그가 끝나면 `active.id`(집은 것)와 `over.id`(놓은 곳)를 이용해 배열을 재정렬한다.


---

## 핵심 개념 3: `useSortable`로 아이템에 드래그 부여

```tsx
function SortableRow({ link, ... }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: link.id });

  return (
    <li ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition }}>
      {/* 핸들에만 listeners 적용 → 핸들을 잡아야만 드래그 가능 */}
      <button {...attributes} {...listeners}>
        <GripVertical />
      </button>
      ...
    </li>
  );
}
```

`listeners`를 전체 row가 아닌 핸들 버튼에만 붙이면, 버튼 클릭(눈, 삭제)이 드래그와 충돌하지 않는다.

---


## 다음 단계

- 링크 추가 폼 구현
- 링크 수정 인라인 에디터
- Supabase 연동 후 `handleDragEnd`의 TODO에서 `order` 필드 일괄 UPDATE
- 삭제 시 TODO에서 DB DELETE 호출
